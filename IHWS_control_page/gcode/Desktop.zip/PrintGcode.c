/*
 Pi_Serial_test.cpp - SerialProtocol library - demo
 Copyright (c) 2014 NicoHood.  All right reserved.
 Program to test serial communication
 
 Compile with:
 sudo gcc -o Pi_Serial_Test.o Pi_Serial_Test.cpp -lwiringPi -DRaspberryPi -pedantic -Wall
 sudo ./Pi_Serial_Test.o
 */
//sudo gcc -o test SendGcode.c -lwiringPi -DRaspberryPi 
// just that the Arduino IDE doesnt compile these files.
#ifdef RaspberryPi 
 
//include system librarys
#include <stdio.h> //for printf
#include <stdint.h> //uint8_t definitions
#include <stdlib.h> //for exit(int);
#include <string.h> //for errno
#include <errno.h> //error output
 
//wiring Pi
#include <wiringPi.h>
#include <wiringSerial.h>

#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
 
// Find Serial device on Raspberry with ~ls /dev/tty*
// ARDUINO_UNO "/dev/ttyACM0"
// FTDI_PROGRAMMER "/dev/ttyUSB0"
// HARDWARE_UART "/dev/ttyAMA0"
char device[]= "/dev/ttyACM0";
int arg_num; //global variable for argc
char* arg_arr[10]; //global variable for argv
// filedescriptor
int fd, in;
int end=1;
int first=1;
char chk_end[40];
int chk_end_offset=0;
char* filename=" ";
unsigned long baud = 115200;
unsigned long time=0;
 
//prototypes
int main(int argc, char* argv[]);
void loop(void);
void setup(void);
 
void setup(){
 
	if(first){
		printf("%s \n", "Raspberry Startup!");
		fflush(stdout);

		int j=arg_num;
		while(j>=0){
			printf("arg_arr[%d]=%s\n",j,arg_arr[j]);
			j--;
		}
		sleep(1);
 
		//get filedescriptor
		if ((fd = serialOpen (device, baud)) < 0){
			fprintf (stderr, "Unable to open serial device: %s\n", strerror (errno)) ;
			exit(1); //error
		}

  //printf("before open\n"); 
  //in = open("sample.gcode",O_RDONLY);
  //printf("after open\n");

		//setup GPIO in wiringPi mode
		if (wiringPiSetup () == -1){
			fprintf (stdout, "Unable to start wiringPi: %s\n", strerror (errno)) ;
			exit(1); //error
		}
  	}
	sleep(2);

	while(serialDataAvail(fd)){
		char newChar=serialGetchar(fd);
		printf("%c",newChar);
	}
	fflush(stdout);

	char c;
	int i=0;
	filename=arg_arr[arg_num];
	//char *command="M23 testm9~1.gco\nM24\n";
	char command[100]="M23 ";
	strcat(command,filename);
	strcat(command,"\nM24\n");
	printf("%s",command);
	while(command[i]!=NULL){
		serialPutchar(fd,command[i++]);
		//serialPutchar(fd,'\n');
		/*
		if(serialDataAvail(fd)){
			char newChar=serialGetchar(fd);
			printf("%c",newChar);
			fflush(stdout);
		}
		*/
	}
	
	if(serialDataAvail(fd)){
		char newChar=serialGetchar(fd);
		printf("%c",newChar);
	}
	fflush(stdout);

	first=0;
}
 
void loop(){
	char c;
	int a;
	// read signal
	if(serialDataAvail (fd)){
		char newChar = serialGetchar (fd);
		printf("%c", newChar);
		chk_end[chk_end_offset++]=newChar;
		if(newChar=='\n'){
			chk_end[chk_end_offset]='\0';
			if(strcmp(chk_end,"END\n")==0){
				printf("end is searched\n");
				arg_num--;
				printf("[%s] is done.\n",filename);
				if(arg_num>0){ //keep going if there are files 
					end=1;
					printf("\nNext file [%s] exist.\n\n",arg_arr[arg_num]);
					sleep(1);
					setup();
				}
				else{ //stop if no file
					end=0;
					printf("\nAll printing done.\n\n");
					sleep(1);
				}
			}
			else{
				chk_end_offset=0;
			}
		}
		//fflush(stdout);
	}
}

// main function for normal c++ programs on Raspberry
int main(int argc, char* argv[]){
	arg_num=argc-1; //for array index
	int l=arg_num;
	while(l>=0){
		arg_arr[l]=argv[l];
		l--;
	}
	setup();
	while(end) loop();
		
  /*
  char *command="M29\n";
  int i=0;
  while(command[i]!=NULL){
    serialPutchar(fd,command[i++]);
    //serialPutchar(fd,'\n');
    if(serialDataAvail(fd)){
      char newChar=serialGetchar(fd);
      
      printf("%c",newChar);
      fflush(stdout);
    }
  }
*/
	sleep(1);
	return 0;
}

#endif //#ifdef RaspberryPi

